﻿using APIpz.entities;
using APIpz.Exceptions;
using APIpz.Middleware;
using APIpz.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace APIpz.Services
{
    public interface ILoginService
    {
        void RegisterUser(RegisterUserDto dto);
        string GenerateJwt(LoginDto dto);
    }

    public class LoginService : ILoginService
    {
        private readonly BazaDbContext _context;
        private readonly IPasswordHasher<Uzytkownik> _passwordHasher;
        private readonly ILogger<ErrorHandlingMiddleware> _logger;
        private readonly AuthenticationSettings _authenticationSettings;
        public LoginService(BazaDbContext context, IPasswordHasher<Uzytkownik> passwordHasher, ILogger<ErrorHandlingMiddleware> logger, AuthenticationSettings authenticationSettings)
        {
            _context = context; 
            _passwordHasher = passwordHasher;
            _logger = logger;
            _authenticationSettings = authenticationSettings;

        }
        public void RegisterUser(RegisterUserDto dto)
        {
            var newUzytkownik = new Uzytkownik()
            {
                Email = dto.Email,
                Login = dto.Login,
                CzyAdmin = dto.CzyAdmin
            };

            var HashOdHasla = _passwordHasher.HashPassword(newUzytkownik, dto.HasloHash);
            newUzytkownik.HasloHash = HashOdHasla;
            _context.Uzytkownicy.Add(newUzytkownik); 
            _context.SaveChanges();
        }

        public string GenerateJwt(LoginDto dto)
        {
            var user = _context.Uzytkownicy.FirstOrDefault(u =>  u.Login == dto.Login);
            if (user is null)
            {
                throw new BadRequestException("niepoprawny login lub haslo");
            }

            var result = _passwordHasher.VerifyHashedPassword(user, user.HasloHash, dto.Password);
            if (result == PasswordVerificationResult.Failed)
            {
                throw new BadRequestException("niepoprawny login lub haslo");
            }

            var claims = new List<Claim>()
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, $"{user.Login} {user.Email}"),
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_authenticationSettings.JwtKey));
            var cred = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.Now.AddDays(_authenticationSettings.JwtExpireDays);

            var token = new JwtSecurityToken(_authenticationSettings.JwtIssuer,
                                             _authenticationSettings.JwtIssuer,
                                             claims, expires: expires, signingCredentials: cred);

            var tokenHandler = new JwtSecurityTokenHandler();
            return tokenHandler.WriteToken(token);
        }
    }
}
